package com.hungnq40.myapplication1.slot9;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Slot9SqliteHelper extends SQLiteOpenHelper {
    public static final String SQL_CREATE_PRODUCT=
            "CREATE TABLE Product (id text PRIMARY KEY, name text, price real);";
    //ham tao CSDL
    public Slot9SqliteHelper(@Nullable Context context) {
        super(context, "DB1", null, 1);
    }
    //tao bang du lieu
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_PRODUCT);
    }
    //upgrade bang du lieu
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Product");
    }
}
