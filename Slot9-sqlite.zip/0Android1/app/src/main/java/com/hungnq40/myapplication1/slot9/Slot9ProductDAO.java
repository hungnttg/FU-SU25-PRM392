package com.hungnq40.myapplication1.slot9;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Slot9ProductDAO {
    private Slot9SqliteHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;
    //ham khoi tao: tao db
    public Slot9ProductDAO(Context context) {
        this.context = context;
        dbHelper=new Slot9SqliteHelper(context);//tao csdl
        db=dbHelper.getWritableDatabase();//cho phep ghi du lieu
    }
    //ham insert
    public int insertProduct(Slot9Product p){
        ContentValues values=new ContentValues();//luu tru du lieu can them vao bang
        //put data
        values.put("id",p.getId());
        values.put("name",p.getName());
        values.put("price",p.getPrice());
        //insert
        if(db.insert("Product",null,values)<0){//neu insert khong thanh cong
            return -1;
        }
        return 1;//insert thanh cong
    }
    //ham select all
    public List<Slot9Product> getAll(){
        //tao list de luu tru
        List<Slot9Product> list = new ArrayList<>();
        //cursor read data
        Cursor c = db.query("Product",null,null,null,null,null,null);
        c.moveToFirst();//di chuyen ve ban ghi dau tien
        while (c.isAfterLast()==false) {//neu khong phai ban ghi cuoi cung -> tiep tuc doc
            Slot9Product p=new Slot9Product();//tao doi tuong luu tru du lieu
            p.setId(c.getString(0));//gan du lieu truong id
            p.setName(c.getString(1));//gan du lieu truong name
            p.setPrice(c.getDouble(2));//gan du lieu truong price
            list.add(p);//them product vao danh sach
            c.moveToNext();//di chuyen dan ban ghi tiep theo de doc
        }
        c.close();//dong con tro
        return list;
    }
}
