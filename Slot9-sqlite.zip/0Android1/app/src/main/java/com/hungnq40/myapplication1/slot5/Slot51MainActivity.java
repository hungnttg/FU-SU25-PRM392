package com.hungnq40.myapplication1.slot5;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Slot51MainActivity extends AppCompatActivity {
    private Slot5Adapter adapter;
    private List<ProductSlot51> productList;
    ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot51_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView = findViewById(R.id.slot51_lv);
        productList = new ArrayList<>();
        adapter= new Slot5Adapter(this,productList);
        listView.setAdapter(adapter);
        //lay du lieu tu server
        new FetchProduct().execute(); //khi goi execute: goi 2 ham: doInBackground, onPostExecute
    }
    private class FetchProduct extends AsyncTask<Void,Void,String>{
        //doc du lieu tu server
        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder response = new StringBuilder();//chua ket qua doc duoc
            try {
                URL url=new URL("https://hungnttg.github.io/shopgiay.json");//duong dan
                HttpURLConnection connection=(HttpURLConnection) url.openConnection();//mo ket noi
                connection.setRequestMethod("GET");//phuong thuc doc du lieu
                //doc du lieu va dua vao bo dem
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                //lay ra tung dong
                String line="";
                while ((line=reader.readLine())!=null){//khi van con du lieu thi tiep tuc doc
                    response.append(line);//dua line vao ket qua
                }
                reader.close();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return response.toString();//tra ve ket qua
        }
        //tra du lieu ve client
        @Override
        protected void onPostExecute(String result) {
            //nhan va xu ly ket qua
            if(result!=null && !result.isEmpty()){
                try {
                    JSONObject json = new JSONObject(result);//lay ve doi tuong
                    JSONArray productArray = json.getJSONArray("products");//lay ve mang products
                    for(int i=0;i<productArray.length();i++){
                        JSONObject productObject = productArray.getJSONObject(i);//lay ve doi tuong cua tung dong
                        String styleid = productObject.getString("styleid");//lay ve truong styleid
                        String brands_filter_facet= productObject.getString("brands_filter_facet");
                        String price = productObject.getString("price");
                        String product_additional_info = productObject.getString("product_additional_info");
                        String search_image = productObject.getString("search_image");
                        //tao product voi nhung thongh tin doc duoc
                        ProductSlot51 product =
                                new ProductSlot51( styleid,brands_filter_facet,price,product_additional_info,search_image);
                        //dua product vao list
                        productList.add(product);
                    }
                    adapter.notifyDataSetChanged();//cap nhat vao adapter
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}