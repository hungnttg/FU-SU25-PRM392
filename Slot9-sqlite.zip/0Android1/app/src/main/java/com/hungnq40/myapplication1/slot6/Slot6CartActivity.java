package com.hungnq40.myapplication1.slot6;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;
import com.hungnq40.myapplication1.slot5.ProductSlot51;

import java.util.List;

public class Slot6CartActivity extends AppCompatActivity {
    ListView listView;
    CartAdapter cartAdapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot6_cart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa
        listView=findViewById(R.id.slot6CartListview);
        //khoi tao danh sach gio hang va dapter
        //bang cach lay 1 intance cua CartManager
        CartManager cartManager=CartManager.getInstance();
        List<ProductSlot51> cartItems = cartManager.getCartItems();
        //khoi tao adapter va thiet lap cho listview
        cartAdapter = new CartAdapter(this,cartItems);
        listView.setAdapter(cartAdapter);
    }
}