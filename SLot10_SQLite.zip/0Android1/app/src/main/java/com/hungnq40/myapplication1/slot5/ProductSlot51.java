package com.hungnq40.myapplication1.slot5;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class ProductSlot51 implements Parcelable {
    private String styleid;
    private String brand;
    private String price;
    private String additionalInfo;
    private String searchImage;

    public ProductSlot51(String styleid, String brand, String price, String additionalInfo, String searchImage) {
        this.styleid = styleid;
        this.brand = brand;
        this.price = price;
        this.additionalInfo = additionalInfo;
        this.searchImage = searchImage;
    }

    public ProductSlot51() {
    }

    protected ProductSlot51(Parcel in) {
        styleid = in.readString();
        brand = in.readString();
        price = in.readString();
        additionalInfo = in.readString();
        searchImage = in.readString();
    }

    public static final Creator<ProductSlot51> CREATOR = new Creator<ProductSlot51>() {
        @Override
        public ProductSlot51 createFromParcel(Parcel in) {
            return new ProductSlot51(in);
        }

        @Override
        public ProductSlot51[] newArray(int size) {
            return new ProductSlot51[size];
        }
    };

    public String getStyleid() {
        return styleid;
    }

    public void setStyleid(String styleid) {
        this.styleid = styleid;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getSearchImage() {
        return searchImage;
    }

    public void setSearchImage(String searchImage) {
        this.searchImage = searchImage;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(styleid);
        dest.writeString(brand);
        dest.writeString(price);
        dest.writeString(additionalInfo);
        dest.writeString(searchImage);
    }
}
