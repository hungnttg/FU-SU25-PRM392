package com.hungnq40.myapplication1.slot9;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.hungnq40.myapplication1.R;

import java.util.List;

public class Slot9Adapter extends BaseAdapter {
    private List<Slot9Product> mList;
    private Context mContext;

    public Slot9Adapter(List<Slot9Product> mList, Context mContext) {
        this.mList = mList;
        this.mContext = mContext;
    }
    //lay ve tong so item
    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);//lay ve 1 item
    }

    @Override
    public long getItemId(int position) {
        return position;//lay ve vi tri cua item
    }
    //tao layout + gan du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. tao view
        Slot9ViewHolder holder;
        if(convertView==null){//neu chua co view -> tao view moi
            //create a blank view
            convertView = LayoutInflater.from(mContext)
                    .inflate(R.layout.slot9_item_row,parent,false);
            //anh xa
            holder=new Slot9ViewHolder();
            holder.tvId=convertView.findViewById(R.id.slot9_item_tvid);
            holder.tvName=convertView.findViewById(R.id.slot9_item_tvname);
            holder.tvPrice=convertView.findViewById(R.id.slot9_item_tvprice);
            holder.btnItemDelete=convertView.findViewById(R.id.slot10_item_btnDelete);
            holder.btnItemEdit=convertView.findViewById(R.id.slot10_item_btnEdit);
            convertView.setTag(holder);//tao template de lan sau su dung
        }
        else {//neu da co view
            holder=(Slot9ViewHolder) convertView.getTag();//lay view ra su dung
        }
        //2. gan du lieu
        Slot9Product p = mList.get(position);
        if(p!=null){
            holder.tvId.setText(p.getId());
            holder.tvName.setText(p.getName());
            holder.tvPrice.setText(String.valueOf(p.getPrice()));
//            xu ly su kien
            holder.btnItemEdit.setOnClickListener(v->{
//                xu ly Edit du lieu

            });
            holder.btnItemDelete.setOnClickListener(v->{
//             xu ly delete
                Slot9ProductDAO dao = new Slot9ProductDAO(mContext);
                int kq = dao.deleteProduct(p.getId());//xoa trong csdl
                mList.remove(position);//xoa o trong list
                notifyDataSetChanged();
            });
        }
        return convertView;
    }
    //tao lop anh xa
    static class Slot9ViewHolder {
        TextView tvId,tvName,tvPrice;
        Button btnItemEdit,btnItemDelete;
    }
}
