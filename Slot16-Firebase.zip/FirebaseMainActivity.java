package com.nqh40.notice1;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.UUID;

public class FirebaseMainActivity extends AppCompatActivity {
    //b1 cai hinh db
    //b2 ket noi voi firebare va tao ten cho collection
    TextView tvKQ;
    Context context=this;
    FirebaseFirestore database;
    String id="";
    ToDo toDo=null;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_firebase_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tvKQ = findViewById(R.id.slot16_tvkq);
        database=FirebaseFirestore.getInstance();//khoi tao database
        //insertFirebase();
        //updateFirebase();
        deleteFirebase();
    }
    public void insertFirebase(){
        //lay 1 ma ngau nhien bat ky
        id= UUID.randomUUID().toString();
        toDo = new ToDo(id,"title 1","content 1");
        HashMap<String,Object> mapTodo = toDo.convertHashMap();//convert sang du lieu co the insert
        database.collection("TODO").document(id)
                .set(mapTodo)//insert
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Them thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvKQ.setText(e.toString());
                    }
                });
    }
    public void updateFirebase(){
        //dua id cua du lieu can update
        id="647c4a62-d546-4d19-a895-6990c7800426";
        toDo=new ToDo(id,"title 1 - sua lan 1","content 1 - sua lan 1");
        database.collection("TODO")//lay ve bang du lieu
                .document(toDo.getId())//lay ve dong du lieu can update
                .update(toDo.convertHashMap())//thuc hien update
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Update thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvKQ.setText(e.toString());
                    }
                });
    }
    public void deleteFirebase(){
        //dua id cua du lieu can update
        id="647c4a62-d546-4d19-a895-6990c7800426";
        database.collection("TODO")
                .document(id)
                .delete()//thuc hien xoa
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvKQ.setText("Xoa thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvKQ.setText(e.getMessage());
                    }
                });
    }
}