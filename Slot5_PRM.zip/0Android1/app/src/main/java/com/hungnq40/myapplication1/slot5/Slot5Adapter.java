package com.hungnq40.myapplication1.slot5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hungnq40.myapplication1.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Slot5Adapter extends BaseAdapter {
    private Context mContext;
    private List<ProductSlot51> list;

    public Slot5Adapter(Context mContext, List<ProductSlot51> list) {
        this.mContext = mContext;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view
    //doc du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView==null)//neu chua co view -> tao view moi
        {
            //tao blank view
            convertView = LayoutInflater.from(mContext)
                    .inflate(R.layout.slot5_item_view,parent,false);
            holder = new ViewHolder();
            //anh xa thanh phan cho view
            holder.imageView = convertView.findViewById(R.id.slot5_itemview_img);
            holder.styleidTextView=convertView.findViewById(R.id.slot5_itemview_styleid);
            holder.brands_filter_facetTextView = convertView.findViewById(R.id.slot5_itemview_brands_filter_facet);
            holder.priceTextView = convertView.findViewById(R.id.slot5_itemview_price);
            holder.product_additional_infoTextView=convertView.findViewById(R.id.slot5_itemview_product_additional_info);
            //tao template de lan sau su dung
            convertView.setTag(holder);
        }
        else  {//khi da co view => lay view cu ra su dung
            holder = (ViewHolder) convertView.getTag();

        }
        //truyen du lieu cho view vua tao
        ProductSlot51 product = list.get(position);
        if(product!=null){
            //dua du lieu anh len imageView
            Picasso.get().load(product.getSearchImage()).into(holder.imageView);
            holder.styleidTextView.setText(product.getStyleid());
            holder.brands_filter_facetTextView.setText(product.getBrand());
            holder.priceTextView.setText(product.getPrice());
            holder.product_additional_infoTextView.setText(product.getAdditionalInfo());
        }
        return convertView;
    }
    static class ViewHolder {
        ImageView imageView;
        TextView styleidTextView;
        TextView brands_filter_facetTextView;
        TextView priceTextView;
        TextView product_additional_infoTextView;
    }
}
