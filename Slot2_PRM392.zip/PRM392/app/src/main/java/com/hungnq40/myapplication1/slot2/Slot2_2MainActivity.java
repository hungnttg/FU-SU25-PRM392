package com.hungnq40.myapplication1.slot2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

public class Slot2_2MainActivity extends AppCompatActivity {
    TextView tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot22_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tv2 = findViewById(R.id.slot2_2Tv2);
        //lay du lieu tu Activity A chuyen sang
        Intent intent1 = getIntent();
        //unboxing
        double so1 = intent1.getDoubleExtra("so1",0);
        double so2 = intent1.getDoubleExtra("so2",0);
        //tinh tong
        double tong = so1 + so2;
        //dua ket qua len man hinh
        tv2.setText(String.valueOf(tong));
    }
}