package com.hungnq40.myapplication1.slot2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

public class Slot2_1MainActivity extends AppCompatActivity {
    //khai bao cac control
    EditText txt1,txt2;
    Button btn1;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot21_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa cac control
        txt1 = findViewById(R.id.slot2_1Txt1);
        txt2 = findViewById(R.id.slot2_1Txt2);
        btn1 = findViewById(R.id.slot2_1Btn1);
        tv1 = findViewById(R.id.slot2_1Tv1);
        //xu ly su kien click button
        btn1.setOnClickListener(v->{
//            //lay du lieu nhap tu o thu 1 -> chuyen sang so
//            double a = Double.parseDouble(txt1.getText().toString());
//            //lay du lieu nhap tu o thu 2 -> chuyen sang so
//            double b = Double.parseDouble(txt2.getText().toString());
//            //tinh tong
//            double tong = a+b;
//            //dua tong ra man hinh
//            tv1.setText(String.valueOf(tong));
            guiDulieu();
        });
    }

    private void guiDulieu() {
        //Xac dinh huong van chuyen du lieu tu A -> B
        Intent intent = new Intent(Slot2_1MainActivity.this,Slot2_2MainActivity.class);
        //dua du lieu vao intent
        intent.putExtra("so1",Double.parseDouble(txt1.getText().toString()));
        intent.putExtra("so2",Double.parseDouble(txt2.getText().toString()));
        //thuc hien van chuyen
        startActivity(intent);
    }

}