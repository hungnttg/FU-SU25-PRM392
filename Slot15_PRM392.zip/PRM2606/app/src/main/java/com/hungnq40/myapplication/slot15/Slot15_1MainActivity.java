package com.hungnq40.myapplication.slot15;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication.R;

public class Slot15_1MainActivity extends AppCompatActivity {
    ListView listView;
    String[] arr =new String[]{"Cam","Xoai","Coc","Oi","Huong duong"};
    ArrayAdapter<String> arrayAdapter;
    Context context = this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot151_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listView = findViewById(R.id.slot15_lv);
        arrayAdapter = new ArrayAdapter<>(context, android.R.layout.simple_list_item_1,arr);
        listView.setAdapter(arrayAdapter);
        registerForContextMenu(listView);//ho tro su dung context menu
    }
//    tao context menu

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.slot15_menu2,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }
//    xu ly su kien cua context menu

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info
                =(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int vitri = info.position;
        if(item.getItemId() == R.id.slot15_1_menu1 || item.getItemId() == R.id.slot15_1_menu2){
            Toast.makeText(context, arr[vitri]+": "+item.getTitle(), Toast.LENGTH_SHORT).show();
        }
        return super.onContextItemSelected(item);
    }
}