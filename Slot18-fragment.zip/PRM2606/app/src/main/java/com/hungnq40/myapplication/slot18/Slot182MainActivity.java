package com.hungnq40.myapplication.slot18;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.hungnq40.myapplication.R;

public class Slot182MainActivity extends AppCompatActivity {
    ViewPager viewPager;
    TabLayout tabLayout;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot182_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        viewPager = findViewById(R.id.slot18_viewpager);
        tabLayout = findViewById(R.id.slot18_tablayout);
        addTabLayout(viewPager);
        tabLayout.setupWithViewPager(viewPager);
    }

    private void addTabLayout(ViewPager viewPager) {
        //tao moi adapter
        Slot18Adapter adapter = new Slot18Adapter(getSupportFragmentManager());
        //them fragment vao adapter
        adapter.addFrag(new Slot18BlankFragment1(),"ONE");
        adapter.addFrag(new Slot18BlankFragment2(),"TWO");
        viewPager.setAdapter(adapter);
    }
}