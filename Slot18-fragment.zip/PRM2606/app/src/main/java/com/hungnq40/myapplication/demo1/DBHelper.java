package com.hungnq40.myapplication.demo1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(@Nullable Context context) {
        super(context, "a1.db", null, 1);//tao csdl
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //tao bang du lieu
        db.execSQL("CREATE TABLE if NOT EXISTS mytable (search_image TEXT NOT NULL," +
                "styleid INTEGER PRIMARY KEY, brands_filter_facet TEXT NOT NULL, " +
                "price INTEGER NOT NULL, product_additional_info TEXT NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS mytable");//xoa bang cu
        onCreate(db);//tao bang moi
    }
    //ham insert
    public void insertSampleData(){
        SQLiteDatabase db = this.getWritableDatabase();//cho phep ghi du lieu
        //lenh insert du lieu
        String sql = "INSERT INTO mytable (search_image,styleid,brands_filter_facet,price,product_additional_info) VALUES " +
                "('http://a.png',1,'Nike',1234,'Giay Nike')," +
                "('http://b.png',2,'Nike',2222,'Giay Nike co nho')";
        db.execSQL(sql);//thuc thi insert
    }
    //---ham sua san pham
    public void updateProduct(int id,int price,String info){
        SQLiteDatabase db = this.getWritableDatabase();//ket noi voi db, cho phep ghi du lieu
        ContentValues cv = new ContentValues();//doi tuong chua du lieu
        cv.put("price",price);//dua price vao content value
        cv.put("product_additional_info",info);
        //thuc hien update ban ghi co id truyen vao
        db.update("mytable",cv,"styleid = ?",new String[]{String.valueOf(id)});
    }
    //viet ham getAll: doc toan bo du lieu trong bang
    public ArrayList<MyItem> getAll(){
        ArrayList<MyItem> list = new ArrayList<>();//tao list chua danh sach san pham
        SQLiteDatabase db = this.getReadableDatabase();//ket noi voi db va doc du lieu
        //su dung con tro de doc du lieu
        Cursor c=db.rawQuery("SELECT styleid, price, product_additional_info FROM mytable",null);
        //di chuyen ve ban ghi dau tien va bat dau doc
        while (c.moveToNext()){
            int id=c.getInt(0);//lay ve truong du lieu dau tien
            int price = c.getInt(1);//lay ve truong du lieu thu 2
            String info = c.getString(2);//lay ve du lieu truong thu 3
            //tao 1 doi tuong va them vao list
            list.add(new MyItem(id,price,info));
        }
        c.close();
        return list;
    }
}
