package com.hungnq40.myapplication.demo1;

public class MyItem {
    int id;
    int price;
    String info;

    public MyItem() {
    }

    public MyItem(int id, int price, String info) {
        this.id = id;
        this.price = price;
        this.info = info;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
