package com.hungnq40.myapplication.b1;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;
import java.util.Random;

public class AdminActivity extends AppCompatActivity {
    DBHelper dbHelper;
    EditText edtInfo, edtPrice;
    Button btnAdd;
    ListView lv;
    ArrayList<String> data;
    ArrayList<Integer> ids;
    ArrayAdapter<String> adapter;
    ArrayList<MyItem> items; //khai bao o b2
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin);

        dbHelper = new DBHelper(this);
        //dong sau chi chay 1 lan
        //dbHelper.insertSampleData();

        edtInfo = findViewById(R.id.edtInfo);
        edtPrice = findViewById(R.id.edtPrice);
        btnAdd = findViewById(R.id.btnAdd);
        lv = findViewById(R.id.lv);

        btnAdd.setOnClickListener(v -> {
            addProduct();
        });

        lv.setOnItemClickListener((parent,
                                   view, position, id) -> {
            deleteProduct(ids.get(position));
        });

        loadData();
        //-------b2--------
        loadList();

        lv.setOnItemClickListener((parent, view, position, id) -> {
            MyItem item = items.get(position);
            showEditDialog(item);
        });
        /// /////end B2//////////

    }
    void loadData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT styleid, product_additional_info, price FROM mytable",
                null);

        data = new ArrayList<>();
        ids = new ArrayList<>();
        while (c.moveToNext()) {
            ids.add(c.getInt(0));
            data.add(c.getString(1) + " - Giá: " + c.getInt(2));
        }
        c.close();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data);
        lv.setAdapter(adapter);
        //start b3
        //→ Mỗi giữ lâu (long click) trên sản phẩm → tự thêm vào giỏ.
        lv.setOnItemLongClickListener((parent, view, position, id) -> {
            MyItem item = items.get(position);
            dbHelper.addToCart(item.id);
            Toast.makeText(this, "Đã thêm vào giỏ!", Toast.LENGTH_SHORT).show();
            return true;
        });
        //---end b3
    }

    void addProduct() {
        String info = edtInfo.getText().toString();
        String price = edtPrice.getText().toString();
        if (info.isEmpty() || price.isEmpty()) return;

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int styleid = new Random().nextInt(99999999) + 1000000;
        db.execSQL("INSERT INTO mytable(styleid, search_image, brands_filter_facet, " +
                        "price, product_additional_info) " +
                        "VALUES (?, '', 'Nike', ?, ?)",
                new Object[]{styleid, Integer.parseInt(price), info});
        loadData();
        edtInfo.setText("");
        edtPrice.setText("");
    }

    void deleteProduct(int styleid) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM mytable WHERE styleid = ?", new Object[]{styleid});
        loadData();
    }
//    start b2====
void loadList() {
    items = dbHelper.getAll();
    ArrayList<String> titles = new ArrayList<>();
    for (MyItem i : items)
        titles.add(i.info);
    adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, titles);
    lv.setAdapter(adapter);
}

    void showEditDialog(MyItem item) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        EditText txtPrice = new EditText(this);
        txtPrice.setHint("Price");
        txtPrice.setText(String.valueOf(item.price));
        layout.addView(txtPrice);

        EditText txtInfo = new EditText(this);
        txtInfo.setHint("Info");
        txtInfo.setText(item.info);
        layout.addView(txtInfo);

        new AlertDialog.Builder(this)
                .setTitle("Edit Product")
                .setView(layout)
                .setPositiveButton("Update", (d, w) -> {
                    int newPrice = Integer.parseInt(txtPrice.getText().toString());
                    String newInfo = txtInfo.getText().toString();
                    dbHelper.updateProduct(item.id, newPrice, newInfo);
                    loadList();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    //====end b2====

}