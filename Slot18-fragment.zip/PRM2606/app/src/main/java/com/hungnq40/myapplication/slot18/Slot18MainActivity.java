package com.hungnq40.myapplication.slot18;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;

import com.hungnq40.myapplication.R;

public class Slot18MainActivity extends AppCompatActivity {
    Button btnSend;
    EditText txtSend;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot18_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnSend = findViewById(R.id.slot18_btn1);
        txtSend = findViewById(R.id.slot18_txt1);
        //xu ly su kien: Truyen du lieu tu activity cho fragment
        btnSend.setOnClickListener(v->{
            //anh xa fragment
            FragmentManager fragmentManager = getSupportFragmentManager();
            Slot18BlankFragment1 fragment1 = (Slot18BlankFragment1) fragmentManager
                    .findFragmentById(R.id.slot18_fragment1);
            //set text cho EditText cua fragment
            fragment1.editText.setText(txtSend.getText().toString());
        });

    }
}