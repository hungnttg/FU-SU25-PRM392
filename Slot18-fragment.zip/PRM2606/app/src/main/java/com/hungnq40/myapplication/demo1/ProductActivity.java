package com.hungnq40.myapplication.demo1;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication.R;

import java.util.ArrayList;
import java.util.Random;

public class ProductActivity extends AppCompatActivity {
    DBHelper dbHelper;
    EditText edtInfo1, edtPrice1;
    Button btnAdd1;
    ListView lv1;
    ArrayList<String> data;
    ArrayList<Integer> ids;
    ArrayAdapter<String> adapter;
    //khai bao item can update
    ArrayList<MyItem> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_product);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa cac thanh phan
        edtInfo1 = findViewById(R.id.edtInfo1);
        edtPrice1 = findViewById(R.id.edtPrice1);
        btnAdd1 = findViewById(R.id.btnAdd1);
        lv1 = findViewById(R.id.lv1);
        //khoi tao database
        dbHelper = new DBHelper(this);
        //neu muon insert thi chay 1 lan
        //dbHelper.insertSampleData();
        //xu ly su kien
        btnAdd1.setOnClickListener(v -> {
            addProduct();//them san pham
        });
        lv1.setOnItemClickListener((parent, view, position, id) -> {
            deleteProduct(ids.get(position));//xoa san pham
        });
        //hien thi san pham
        //loadData();
        //load du lieu chua cac item
        loadList();
        //xu ly su kien update
        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MyItem item = items.get(position);//lay ve vi tri ban click
                //hien thi form sua du lieu
                showEditDialog(item);
            }
        });
    }

    //tao form sua du lieu
    void showEditDialog(MyItem item){
        LinearLayout layout = new LinearLayout(this);//tao layout quan ly
        layout.setOrientation(LinearLayout.VERTICAL);//dinh huong theo chieu vertical
        //them truong price
        EditText txtPrice = new EditText(this);
        txtPrice.setHint("Price");
        txtPrice.setText(String.valueOf(item.price));//gan du lieu cua truong price
        layout.addView(txtPrice);//them truong txtPrice vao form
        //them truong txtInfo vao form
        EditText txtInfo = new EditText(this);
        txtInfo.setHint("Info");
        txtInfo.setText(item.info);
        layout.addView(txtInfo);
        //tao dialog
        new AlertDialog.Builder(this).setTitle("Edit Product")
                .setView(layout)
                //them button update
                .setPositiveButton("Update",(d,w)->{
                    //thuc hien update
                    int newPrice = Integer.parseInt(txtPrice.getText().toString());//lay ve price moi
                    String newInfo=txtInfo.getText().toString();//lay ve info moi
                    dbHelper.updateProduct(item.id,newPrice,newInfo);//thuc hien update trong database
                    loadList();//load lai du lieu
                    //loadData();

                })
                //them button cancel
                .setNegativeButton("Cancel",null)
                //hien thi dialog
                .show();
    }

    private void loadList() {
        items = dbHelper.getAll();//ham lay ve danh sach toan bo san pham
        ArrayList<String> titles = new ArrayList<>();//tao danh sach chua tieu de san pham
        for (MyItem i: items)
        {
            titles.add("San pham: "+i.info +"; Gia: "+ i.price);//them tat ca info vao danh sach titles
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,titles);//dua vao adapter
        lv1.setAdapter(adapter);
    }

    private void loadData() {//doc du lieu len listview
        SQLiteDatabase db = dbHelper.getReadableDatabase();//cho phep doc du lieu
        //tao contro doc du lieu
        Cursor c = db.rawQuery("SELECT styleid, product_additional_info, price FROM mytable",
                null);
        data = new ArrayList<>();//mang chua du lieu
        ids = new ArrayList<>();//mang chua id
        while (c.moveToNext()) {//thuc hien doc du lieu
            ids.add(c.getInt(0));
            data.add(c.getString(1) + " - Gia: " + c.getInt(2));
        }
        c.close();//dong con tro
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data);
        lv1.setAdapter(adapter);

    }

    private void deleteProduct(int styleid) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();//cho phep ghi du lieu
        db.execSQL("DELETE FROM mytable WHERE styleid=?", new Object[]{styleid});//thuc hien xoa
        loadData();//reload du lieu
    }

    private void addProduct() {
        String info = edtInfo1.getText().toString();
        String price = edtPrice1.getText().toString();
        if (info.isEmpty() || price.isEmpty()) return;
        SQLiteDatabase db = dbHelper.getWritableDatabase();//cho pheo ghi du lieu
        int styleid = new Random().nextInt(9999) + 1000;//tao 1 so lam id nam trong khoang
        //thuc hien insert
        db.execSQL("INSERT INTO mytable (styleid,search_image,brands_filter_facet,price,product_additional_info) VALUES (?,'','Nike',?,?)",
                new Object[]{styleid, Integer.parseInt(price), info});
        loadData();//load lai du lieu sau khi insert
        edtInfo1.setText("");//xoa trang du lieu sau khi insert
        edtPrice1.setText("");
    }
}