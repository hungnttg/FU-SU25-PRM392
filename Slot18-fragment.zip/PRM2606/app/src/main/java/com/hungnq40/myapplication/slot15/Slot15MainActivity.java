package com.hungnq40.myapplication.slot15;

import android.content.Context;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication.R;

public class Slot15MainActivity extends AppCompatActivity {
    Button slot15Btn1;
    TextView slot15Tv1;
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot15_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        slot15Btn1 = findViewById(R.id.slot15_btn1);
        slot15Tv1 = findViewById(R.id.slot15_tv1);
//        xu ly su kien
        slot15Btn1.setOnClickListener(v->{
            //b1 - tao menu dang XML
            //b2 -tao menu va gan vao textview
            //PopupMenu(activity,ganVaoPopu)
            PopupMenu popupMenu = new PopupMenu(context,slot15Tv1);
            //tao menu
            MenuInflater inflater = (MenuInflater) popupMenu.getMenuInflater();
            inflater.inflate(R.menu.slot15_menu1,popupMenu.getMenu());
            //hien thi
            popupMenu.show();
            //b3. xu ly su kien cho menu
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    if(item.getItemId() == R.id.slot14_option_menu1 || item.getItemId() == R.id.slot14_option_menu2){
                        slot15Tv1.setText(item.getTitle());
                    }

                    return false;
                }
            });
        });
    }
}