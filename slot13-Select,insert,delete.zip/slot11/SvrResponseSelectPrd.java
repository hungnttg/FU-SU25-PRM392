package com.hungnq40.myapplication1.slot11;

public class SvrResponseSelectPrd {
    private Prd[] products;
    private String message;

    public Prd[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
