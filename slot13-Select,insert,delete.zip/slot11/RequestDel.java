package com.hungnq40.myapplication1.slot11;

public class RequestDel {
    private PrdDel products;

    public void setProducts(PrdDel products) {
        this.products = products;
    }
}
