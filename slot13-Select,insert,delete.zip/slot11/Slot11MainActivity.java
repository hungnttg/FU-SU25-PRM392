package com.hungnq40.myapplication1.slot11;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Slot11MainActivity extends AppCompatActivity {
    EditText txtName,txtPrice,txtDes;
    TextView tvKQ;
    Button btnInsert,btnSelect,btnDelete;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot11_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txtName = findViewById(R.id.slot11_txtName);
        txtPrice = findViewById(R.id.slot11_txtPrice);
        txtDes = findViewById(R.id.slot11_txtDes);
        tvKQ = findViewById(R.id.slot13_tvKQ);
        btnInsert=findViewById(R.id.slot11_btnInsert);
        btnSelect = findViewById(R.id.slot13BtnSelect);
        btnDelete=findViewById(R.id.slot13BtnDelete);
        btnInsert.setOnClickListener(v->{
            insertData();
        });
        btnSelect.setOnClickListener(v->{
            selectData();
        });
        btnDelete.setOnClickListener(v->{
            String pid = txtName.getText().toString();
            deletePrd(pid);
        });
    }

    private void deletePrd(String pid) {
        //1. Tao doi tuong Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0apisl11/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. dua du lieu vao request
        PrdDel p = new PrdDel();
        p.setPid(pid);
        RequestDel requestDel=new RequestDel();
        requestDel.setProducts(p);
        //3. goi interface (thuc thi + tra ve ket qua)
        InterfaceDelete interfaceDelete=retrofit.create(InterfaceDelete.class);
        Call<ResponseDel> call = interfaceDelete.deletePrd(pid);
        //4. Thuc thi
        call.enqueue(new Callback<ResponseDel>() {
            @Override
            public void onResponse(Call<ResponseDel> call, Response<ResponseDel> response) {
                ResponseDel responseDel=response.body();
                tvKQ.setText(responseDel.getMessage());
            }

            @Override
            public void onFailure(Call<ResponseDel> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }

    List<Prd> ls;
    String strKQ = "";
    private void selectData() {
        //chuoi chua ket qua
        //1. Tao doi tuong
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0apisl11/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. goi ham select trong interface
        //2.1 tao doi tuong
        InterfaceSelectPrd interfaceSelectPrd = retrofit.create(InterfaceSelectPrd.class);
        //2.2 chuan bi ham
        Call<SvrResponseSelectPrd> call = interfaceSelectPrd.getProd();
        call.enqueue(new Callback<SvrResponseSelectPrd>() {
            @Override
            public void onResponse(Call<SvrResponseSelectPrd> call, Response<SvrResponseSelectPrd> response) {
                //thanh cong
                SvrResponseSelectPrd svrResponsePrd = response.body();//lay ve ket qua do server tra ve
                //chuyen ket qua sang dang list
                ls=new ArrayList<Prd>(Arrays.asList(svrResponsePrd.getProducts()));
                //doc du lieu bang cach dua vao vong lap
                for(Prd p: ls){
                    strKQ +="Name: "+p.getName()+"; Price: "+p.getPrice()+";Des: "+p.getDescription();
                    tvKQ.setText(strKQ);
                }
            }

            @Override
            public void onFailure(Call<SvrResponseSelectPrd> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }

    private void insertData() {
        //b1. Tao doi tuong chua du lieu
        Prd prd = new Prd();
        //b2. dua du lieu vao doi tuong
        prd.setName(txtName.getText().toString());
        prd.setPrice(txtPrice.getText().toString());
        prd.setDescription(txtDes.getText().toString());
        //b3. tao doi tuong Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0apisl11/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //b4. goi ham insert trong interface
        InterfaceInsertPrd interfaceInsertPrd=retrofit.create(InterfaceInsertPrd.class);
        Call<SvrResponsePrd> call=interfaceInsertPrd.insertPrd(prd.getName(),prd.getPrice(),prd.getDescription());
        //b5. thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd = response.body();
                Toast.makeText(Slot11MainActivity.this, "Thanh cong:" +svrResponsePrd.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                Toast.makeText(Slot11MainActivity.this, "Loi: "+t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}