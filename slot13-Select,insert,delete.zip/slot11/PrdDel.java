package com.hungnq40.myapplication1.slot11;

public class PrdDel {
    private String pid;

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }
}
