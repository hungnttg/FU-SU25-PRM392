package com.hungnq40.myapplication1.slot11;

public class ResponseDel {
    private PrdDel products;
    private String message;

    public PrdDel getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
