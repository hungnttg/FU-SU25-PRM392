package com.hungnq40.myapplication1.slot11;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Slot11MainActivity extends AppCompatActivity {
    EditText txtName,txtPrice,txtDes;
    Button btnInsert;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot11_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txtName = findViewById(R.id.slot11_txtName);
        txtPrice = findViewById(R.id.slot11_txtPrice);
        txtDes = findViewById(R.id.slot11_txtDes);
        btnInsert=findViewById(R.id.slot11_btnInsert);
        btnInsert.setOnClickListener(v->{
            insertData();
        });
    }

    private void insertData() {
        //b1. Tao doi tuong chua du lieu
        Prd prd = new Prd();
        //b2. dua du lieu vao doi tuong
        prd.setName(txtName.getText().toString());
        prd.setPrice(txtPrice.getText().toString());
        prd.setDescription(txtDes.getText().toString());
        //b3. tao doi tuong Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.22.10.72/0apisl11/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //b4. goi ham insert trong interface
        InterfaceInsertPrd interfaceInsertPrd=retrofit.create(InterfaceInsertPrd.class);
        Call<SvrResponsePrd> call=interfaceInsertPrd.insertPrd(prd.getName(),prd.getPrice(),prd.getDescription());
        //b5. thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                SvrResponsePrd svrResponsePrd = response.body();
                Toast.makeText(Slot11MainActivity.this, "Thanh cong:" +svrResponsePrd.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                Toast.makeText(Slot11MainActivity.this, "Loi: "+t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}