<?php
header('Access-Full-Control-Origin: *');
$host = "localhost";$u="root";$p="";$db="a6";
$conn = new mysqli($host,$u,$p,$db);
$result = $conn->query("select * from products");
while($row[]=$result->fetch_assoc()){
    $json = json_encode($row);
}
echo '{"products":'.$json.'}';
$conn->close();