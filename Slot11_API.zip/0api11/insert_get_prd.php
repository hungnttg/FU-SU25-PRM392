<?php
$response = array();
$host = "localhost";$u="root";$p="";$db="a6";
$conn = new mysqli($host,$u,$p,$db);
//http://10.22.10.72/0api11/insert_get_prd.php?id=123&name=ten&price=456&description=mota
if(isset($_GET['id']) && isset($_GET['name']) & isset($_GET['price']) && isset($_GET['description'])){
    $id=$_GET['id'];
    $name=$_GET['name'];
    $price=$_GET['price'];
    $description=$_GET['description'];
    $result = $conn->query("insert into products values ('$id','$name','$price','$description')");
    if($result===TRUE){
        $response['success']=1;
        $response['message']="insert thanh cong";
        echo json_encode($response);
    }
    else{
        $response['success']=0;
        $response['message']="insert that bai";
        echo json_encode($response);
    }
    $conn->close();
}