<?php
$response = array();
$host = "localhost";$u="root";$p="";$db="a6";
$conn = new mysqli($host,$u,$p,$db);
if(isset($_POST['id'])){
    $id=$_POST['id'];
    $result = $conn->query("delete from products where id='$id'");
    if($result===TRUE){
        $response['success']=1;
        $response['message']="Delete thanh cong";
        echo json_encode($response);
    }
    else{
        $response['success']=0;
        $response['message']="Delete that bai";
        echo json_encode($response);
    }
    $conn->close();
}