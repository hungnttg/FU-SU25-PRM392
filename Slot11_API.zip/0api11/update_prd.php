<?php
$response = array();
$host = "localhost";$u="root";$p="";$db="a6";
$conn = new mysqli($host,$u,$p,$db);
if(isset($_POST['id']) && isset($_POST['name']) & isset($_POST['price']) && isset($_POST['description'])){
    $id=$_POST['id'];
    $name=$_POST['name'];
    $price=$_POST['price'];
    $description=$_POST['description'];
    $result = $conn->query("update products set name='$name',price='$price',
    description='$description' where id='$id'");
    if($result===TRUE){
        $response['success']=1;
        $response['message']="update thanh cong";
        echo json_encode($response);
    }
    else{
        $response['success']=0;
        $response['message']="update that bai";
        echo json_encode($response);
    }
    $conn->close();
}