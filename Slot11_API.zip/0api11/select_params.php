<?php
header('Access-Full-Control-Origin: *');
$host = "localhost";$u="root";$p="";$db="a6";
$conn = new mysqli($host,$u,$p,$db);
if(isset($_GET['id'])){
    $result = $conn->query("select * from products where id='$id'");
}

while($row[]=$result->fetch_assoc()){
    $json = json_encode($row);
}
echo '{"products":'.$json.'}';
$conn->close();