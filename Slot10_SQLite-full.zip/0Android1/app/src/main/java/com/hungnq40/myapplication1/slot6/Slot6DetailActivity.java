package com.hungnq40.myapplication1.slot6;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;
import com.hungnq40.myapplication1.slot5.ProductSlot51;
import com.squareup.picasso.Picasso;

public class Slot6DetailActivity extends AppCompatActivity {
    private CartManager cartManager;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot6_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //lay 1 the hien duy nhat cua cartmanager lam bien toan cuc
        cartManager = CartManager.getInstance();
        //lay du lieu chuyen tu listproduct
        Intent intent=getIntent();
        ProductSlot51 product=intent.getParcelableExtra("PRODUCT");
        //anh xa cac thanh phan giao dien
        ImageView imageView = findViewById(R.id.slot6_item_imageview);
        TextView styleidTv = findViewById(R.id.slot6_item_styleid);
        TextView brands_filter_facetTv = findViewById(R.id.slot6_item_brands_filter_facet);
        TextView priceTv = findViewById(R.id.slot6_item_price);
        TextView product_additional_infoTv = findViewById(R.id.slot6_item_product_additional_info);

        Button btnAddToCart = findViewById(R.id.slot6_item_btnAddToCart);
        btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToCartFn();
            }
        });
        //hien thi thong tin chi tiet
        if(product != null){
            //hien thi anh
            Picasso.get().load(product.getSearchImage()).into(imageView);
            //hien thi text
            styleidTv.setText("Style ID: "+product.getStyleid());
            brands_filter_facetTv.setText("Brand: "+product.getBrand());
            priceTv.setText("Price: "+product.getPrice());
            product_additional_infoTv.setText("Addition Info: "+product.getAdditionalInfo());
        }

    }

    private void addToCartFn() {
        Intent intent = getIntent();
        ProductSlot51 product=intent.getParcelableExtra("PRODUCT");
        if(product!=null){
            //them san pham vao gio hang
            cartManager.addProductToCart(product);
            //mo CartActivity
            Intent cartIntent = new Intent(Slot6DetailActivity.this,Slot6CartActivity.class);
            startActivity(cartIntent);
        }
    }
}