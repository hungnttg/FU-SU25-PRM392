package com.hungnq40.myapplication1.slot9;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot9MainActivity extends AppCompatActivity {
    ListView listView;
    Slot9Adapter adapter;
    EditText txtId,txtName,txtPrice;
    Button btnInsert,btnUpdate,btnSelect;
    List<Slot9Product> list=new ArrayList<>();
    Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot9_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //anh xa
        listView=findViewById(R.id.slot9Listview);
        txtId = findViewById(R.id.slot10_txtId);
        txtName = findViewById(R.id.slot10_txtName);
        txtPrice=findViewById(R.id.slot10_txtPrice);
        btnInsert=findViewById(R.id.slot10_btnInsert);
        btnUpdate=findViewById(R.id.slot10_btnUpdate);
        btnSelect=findViewById(R.id.slot10_btnGetAll);
        Slot9ProductDAO dao = new Slot9ProductDAO(this);//tao database
        //insert san pham
        //Slot9Product p = new Slot9Product("3","San pham 3",2323);
        //int kq = dao.insertProduct(p);
        //Log.e("Ket qua: ",String.valueOf(kq));
        list=dao.getAll();//doc du lieu tu csdl
        adapter = new Slot9Adapter(list,this);
        listView.setAdapter(adapter);
//        xu ly su kien insert
        btnInsert.setOnClickListener(v->{
//            tao san pham voi du lieu nhap vao
            Slot9Product p = new Slot9Product(txtId.getText().toString(),
                    txtName.getText().toString(),
                    Double.parseDouble(txtPrice.getText().toString()));
            //        thuc hien insert
            int kq = dao.insertProduct(p);
            if(kq<0){
//                hien thi thong bao that bai
                Toast.makeText(getApplicationContext(),"Insert that bai",Toast.LENGTH_LONG).show();
            }
            else {
//                reload du lieu
                list.clear();
                list=dao.getAll();//doc du lieu tu csdl
                adapter = new Slot9Adapter(list,context);
                listView.setAdapter(adapter);
                Toast.makeText(getApplicationContext(),"Insert thanh cong",Toast.LENGTH_LONG).show();
            }

        });
        btnUpdate.setOnClickListener(v->{
            //thuc hien update du lieu
            // Lấy thông tin từ EditText
            String id = txtId.getText().toString();
            String name = txtName.getText().toString();
            double price;
            try {
                price = Double.parseDouble(txtPrice.getText().toString());
            } catch (NumberFormatException e) {
                Toast.makeText(getApplicationContext(), "Giá không hợp lệ", Toast.LENGTH_SHORT).show();
                return;
            }

            // Tạo sản phẩm mới với thông tin đã nhập
            Slot9Product product = new Slot9Product(id, name, price);
            int kq = dao.updateProduct(product);
            if (kq <= 0) {
                Toast.makeText(getApplicationContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                // reload danh sách
                list.clear();
                list.addAll(dao.getAll());
                adapter.notifyDataSetChanged();
            }
        });

    }
    public void setFormData(Slot9Product p) {
        txtId.setText(p.getId());
        txtName.setText(p.getName());
        txtPrice.setText(String.valueOf(p.getPrice()));
    }

}