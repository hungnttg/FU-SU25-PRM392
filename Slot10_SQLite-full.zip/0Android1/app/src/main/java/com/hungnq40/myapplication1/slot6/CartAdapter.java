package com.hungnq40.myapplication1.slot6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hungnq40.myapplication1.R;
import com.hungnq40.myapplication1.slot5.ProductSlot51;

import java.util.List;

public class CartAdapter extends ArrayAdapter<ProductSlot51> {
    private Context mContext;
    public CartAdapter(@NonNull Context context,  @NonNull List<ProductSlot51> products) {
        super(context, 0, products);
        mContext=context;
    }
    //ham tao view
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem==null){
            //tao blank view
            listItem = LayoutInflater.from(mContext).inflate(R.layout.slot6_cart_item,parent,false);
        }
        //lay san pham hien tai
        ProductSlot51 currentProduct = getItem(position);
        //hien thi thong tin san pham
        TextView productName = listItem.findViewById(R.id.slot6_itemview_name);
        productName.setText(currentProduct.getStyleid());
        TextView productPrice = listItem.findViewById(R.id.slot6_itemview_price);
        productPrice.setText(currentProduct.getPrice());
        //so luong
        TextView productQuantity=listItem.findViewById(R.id.slot6_itemview_quantity);
        productQuantity.setText("Quantity: "+1);
        return listItem;
    }
}
