package com.hungnq40.myapplication1.slot4;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.hungnq40.myapplication1.R;

import java.util.ArrayList;
import java.util.List;

public class Slot4_1MainActivity extends AppCompatActivity {
    ListView lv;
    List<Slot4Student> list = new ArrayList<>();
    Slot4BaseAdapter adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_slot41_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        lv = findViewById(R.id.slot4_1Lv);
        //tao nguon du lieu
        list.add(new Slot4Student("Nguyen Van An","18",R.drawable.android));
        list.add(new Slot4Student("TRan Van Ben","20",R.drawable.apple));
        list.add(new Slot4Student("Vu Van Cong","17",R.drawable.blogger));
        list.add(new Slot4Student("Hoang Van Dung","23",R.drawable.chrome));
        list.add(new Slot4Student("Le Van Giang","19",R.drawable.dell));
        list.add(new Slot4Student("Nguyen Van HUng","18",R.drawable.facebook));
        //tao adapter
        adapter = new Slot4BaseAdapter(this,list);
        //gan apdapter vao listview
        lv.setAdapter(adapter);

    }
}