package com.hungnq40.myapplication1.slot6;

import com.hungnq40.myapplication1.slot5.ProductSlot51;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    //quan ly gio hang
    private static CartManager instance;
    private List<ProductSlot51> cartItems;
    //khoi tao gio hang blank
    public CartManager() {
        cartItems = new ArrayList<>();
    }
    //cap nhat gio hang
    public static synchronized CartManager getInstance(){
        if(instance==null){
            instance=new CartManager();//neu chua co gio hang thi tao moi
        }
        return instance;//tra ve gio hang
    }
    //them san pham vao gio hang
    public void addProductToCart(ProductSlot51 product){
        cartItems.add(product);
    }
    //danh san pham trong gio hang
    public List<ProductSlot51> getCartItems(){
        return cartItems;
    }
}
