<?php
function ketNoiDB(){
    return new mysqli('localhost','root','','a6');//ket noi voi csdl
}
function addSP($ma,$ten,$dg,$sl){//ham them moi 1 san pham
    $conn = ketNoiDB();
    $i=$conn->query('INSERT INTO SanPham VALUES ("'.$ma.'","'.$ten.'","'.$dg.'","'.$sl.'")');
    return $i;
}
function displaySP(){//ham hien thi san pham
    $conn=ketNoiDB();
    $result=$conn->query('SELECT * FROM SanPham');
    return $result;
}
function updateSP($ma,$ten,$dg,$sl){//update san pham
    $conn = ketNoiDB();
    $i=$conn->query('UPDATE SanPham SET TenSP="'.$ten.'", DonGia="'.$dg.'", SoLuong="'.$sl.'" WHERE MaSP="'.$ma.'"');
    return $i;
}
function deleteSP($ma){//xoa san pham
    $conn = ketNoiDB();
    $i=$conn->query('DELETE FROM SanPham WHERE MaSP="'.$ma.'"');
    return $i;
}