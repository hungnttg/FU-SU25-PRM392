<!doctype html>
<?php
session_start();//bat dau 1 phien lam viec
require_once('SP.php');//tham chieu den thu vien
global $result;//bien toan cuc chua ket qua
$editMaSP = "";
//ham isset de kiem tra su kien, xac dinh xem du lieu gui den la GET, POST
if(isset($_POST['btnEdit'])){//neu button edit duoc click
  $editMaSP = $_POST['editMaSP'];//luu gia tri MaSP trong bien $editMaSP
}
?>
<html lang="en">
  <head>
    <title>Quan tri san pham</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      <div class="jumbotron">
        <h1 class="display-3">Quan tri san pham</h1>
      </div>
      <div class="card-columns">
        <div class="card">
            <img class="card-img-top" src="holder.js/100x180/" alt="">
            <div class="card-body">
                <h4 class="card-title">Them san pham</h4>
                <form accept="" method="post">
                    <div class="form-group">
                      <label for="txtMaSP">Ma san pham</label>
                      <input type="text"
                        class="form-control" name="txtMaSP" id="txtMaSP" value="<?php echo $editMaSP; ?>" placeholder="">
                    </div>
                    <div class="form-group">
                      <label for="txtTenSP">Ten san pham</label>
                      <input type="text"
                        class="form-control" name="txtTenSP" id="txtTenSP" aria-describedby="helpId" placeholder="">
                    </div>
                    <div class="form-group">
                      <label for="txtDonGia">Don gia san pham</label>
                      <input type="text"
                        class="form-control" name="txtDonGia" id="txtDonGia" aria-describedby="helpId" placeholder="">
                    </div>
                    <div class="form-group">
                      <label for="txtDonGia">So luong san pham</label>
                      <input type="text"
                        class="form-control" name="txtSoLuong" id="txtSoLuong" aria-describedby="helpId" placeholder="">
                    </div>
                    <button type="submit" name="btnThem" class="btn btn-primary">Them</button>
                    <button type="submit" name="btnHienThi" class="btn btn-primary">Hien thi</button>
                    <button type="submit" name="btnUpdate" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="holder.js/100x180/" alt="">
            <div class="card-body">
                <h4 class="card-title">Danh sach san pham</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>MaSP</th>
                            <th>TenSP</th>
                            <th>DonGia</th>
                            <th>SoLuong</th>
                            <th>...</th>
                            <th>...</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php
                        if(isset($_POST['btnHienThi'])){//neu button hien thi duoc click
                            $result=displaySP();//doc du lieu tu csdl va tra ve bien $result
                            // xu ly result
                            while($row=$result->fetch_assoc()){//doc tung dong trong $result
                                echo '<tr>';
                                echo '<td scope="row">'.$row['MaSP'].'</td>';
                                echo '<td>'.$row['TenSP'].'</td>';
                                echo '<td>'.$row['DonGia'].'</td>';
                                echo '<td>'.$row['SoLuong'].'</td>';
                                echo '<td>';
                                echo '<form action="" method="post">
                                        <input type="hidden" name="editMaSP" value="'.$row['MaSP'].'">
                                        <button type="submit" name="btnEdit" class="btn btn-primary">Edit</button>
                                      </form>';  
                                echo'</td>';
                                echo '<td>';
                                echo '<form action="" method="post">
                                        <input type="hidden" name="deleteMaSP" value="'.$row['MaSP'].'">
                                        <button type="submit" name="btnDelete" class="btn btn-primary">Delete</button>
                                      </form>';  
                                echo'</td>';
                                echo '</tr>';
                            }
                        }
                      ?>
                    </tbody>
                </table>
            </div>
        </div>
      </div>
      <?php
        if(isset($_POST['btnThem'])){//neu click vao button them
          //lay du lieu tu form nguoi dung
          $MaSP = $_POST['txtMaSP'];//lay ma nhap tu form nguoi dung
          $TenSP = $_POST['txtTenSP'];
          $DonGia = $_POST['txtDonGia'];
          $SoLuong=$_POST['txtSoLuong'];
          //goi ham them du lieu
          $i=addSP($MaSP,$TenSP,$DonGia,$SoLuong);
          if($i<0){
            echo "Them that bai";
          }
          else
          {
            echo "Them thanh cong";
          }
          }
            // khi click button Edit
            if(isset($_POST['btnEdit'])){
              $MaSP = $_POST['editMaSP'];//lay ve ma san pham can sua
              echo "Hay nhap cac thong tin can sua voi MaSP la: $MaSP";
            }
            // khi click button Delete
            if(isset($_POST['btnDelete'])){
              $MaSP = $_POST['deleteMaSP'];//lay ve ma sp can xoa
              $i=deleteSP($MaSP);//thuc hien xoa
              if($i<0){
                    echo "Xoa that bai";
                    }
                    else
                    {
                      echo "Xoa thanh cong";
                    }
            }
            //khi nguoi dung click button update
            if(isset($_POST['btnUpdate'])){//neu click vao button them
            //lay du lieu tu form nguoi dung
            $MaSP = $_POST['txtMaSP'];//lay ma nhap tu form nguoi dung
            $TenSP = $_POST['txtTenSP'];
            $DonGia = $_POST['txtDonGia'];
            $SoLuong=$_POST['txtSoLuong'];
            //goi ham them du lieu
            $i=updateSP($MaSP,$TenSP,$DonGia,$SoLuong);
            if($i<0){
              echo "Update that bai";
            }
            else
            {
              echo "Update thanh cong";
            }
            }

        
      ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>